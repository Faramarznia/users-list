import usersData from "./data/users.json";
import UserList from "./components/UserList";
import AverageAge from "./components/AverageAge";

const App = () => {
  return (
    <div>
      <UserList
        users={usersData
          .filter((order) => order.role === "user")
          .map((item) => item)}
      />
      <AverageAge
        average={
          usersData
            .filter((order) => order.role === "admin")
            .map((item) => item.age)
            .reduce((a, b) => a + b, 0) / 5
        }
      />
    </div>
  );
};


export default App;
